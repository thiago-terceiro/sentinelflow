"""Training and ONNX export pipeline for SentinelPulse SMS Fraud & Spam Classifier.

Trains an NLP pipeline (TF-IDF + calibrated Logistic Regression) on representative
telecom SMS traffic, evaluates precision/recall/F1, and exports directly to an
optimized ONNX Runtime model with CPU execution provider.
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
from pathlib import Path
from typing import Any

from app.telecom.evaluate_model import (
    evaluate_onnx_model,
    export_ml_metrics,
    get_held_out_evaluation_set,
)
from skl2onnx import to_onnx
from skl2onnx.common.data_types import StringTensorType
from sklearn.calibration import CalibratedClassifierCV
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    classification_report,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.pipeline import Pipeline

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# Curated dataset of typical A2P / P2P legit messages (label=0) vs Smishing/Spam (label=1)
LEGITIMATE_MESSAGES: list[str] = [
    "Your verification code is 849201. It expires in 10 minutes. Do not share this code.",
    "Carrier security code: 4920. Valid for 5 minutes. carrier.com/verify",
    "Your Uber ride is arriving now. Driver: Ahmed in a Toyota Camry (Plate: 7XYZ89).",
    "Your card ending in 4102 was charged $14.50 at Trader Joe's. Available balance: $1,240.10.",
    "USPS tracking #940011189956: Your package is out for delivery and will arrive by 7:00 PM.",
    "Reminder: Your dental cleaning with Dr. Smith is tomorrow at 2:00 PM. Reply 1 to confirm, 2 to reschedule.",
    "Hey! Are you still free for dinner tonight around 7?",
    "Your appointment with Quest Diagnostics is scheduled for Thursday, Oct 24 at 9:30 AM.",
    "Your prescription is ready for pickup at Walgreens Pharmacy on Main Street.",
    "Google prompt: Tap YES on your phone to approve sign-in from Chrome on Windows.",
    "Amazon: Your order #112-4920491 has shipped and will arrive on Wednesday.",
    "Delta Flight DL492 is on time. Gate B12. Boarding begins at 3:15 PM.",
    "Wells Fargo Fraud Alert: Did you attempt $89.20 at Target? Reply YES or NO.",
    "Running about 10 minutes late, see you guys soon!",
    "Your monthly electric bill of $78.40 is scheduled for autopay on Nov 1. Thank you.",
    "Lyft code 382910. Reply STOP to opt out.",
    "Your DoorDash order from Chipotle is being prepared and will arrive in 25-35 minutes.",
    "Hey mom, just landed safely at JFK. Will text when I get to the hotel.",
    "Bank of America: A direct deposit of $3,250.00 was posted to your account ending in 8821.",
    "Your haircut appointment with Alex is confirmed for Saturday at 11:00 AM.",
    "Security notice: A new device logged into your Slack workspace. Review at my.slack.com",
    "Your test results are ready in the MyChart patient portal.",
    "Thanks for visiting Blue Bottle Coffee! Here is your digital receipt: squareup.com/r/xyz",
    "Great presentation today, let's sync up on Monday to discuss next steps.",
    "Your reservation at Osteria Morini is confirmed for 4 guests on Friday at 8:00 PM.",
    "FedEx Delivery: Package with tracking 78291038472 was delivered to your front porch.",
    "Hi Sarah, can you review the pull request when you get a chance? Thanks!",
    "Your two-factor authentication token is 501928 for login to GitHub.",
    "Your gym membership renewal receipt for $49.00 has been processed.",
    "Can you pick up milk on your way home please?",
    "Your reservation at Hyatt Regency is confirmed. Check-in is at 3 PM.",
    "Your package has been placed in Amazon Locker 'Sparrow'. Use code 829104 to collect.",
    "Home Depot: Your store pickup order #W928103 is ready at the customer service desk.",
    "Hi David, thanks for following up. Let's schedule a 30-minute intro call next Tuesday.",
    "Microsoft account security code: 928371. If you didn't request this, ignore.",
    "Your order from Apple Store is confirmed. Order number: W938472910.",
    "Your weekly screen time report is now available in settings.",
    "Good morning team, the 9:30 AM standup will be pushed by 15 minutes today.",
    "Southwest Airlines: Boarding position A24 for flight WN1849 to Denver.",
    "Your library books are due in 3 days. Renew online at publiclibrary.org",
]

FRAUDULENT_MESSAGES: list[str] = [
    "URGENT: Chase Bank alert. Unusual activity detected. Account suspended. Restore immediately: http://bit.ly/chase-verify-now",
    "CONGRATULATIONS! Your phone number won a $1,000 Walmart gift card! Click here to claim: http://walmart-prizes2026.xyz/win",
    "USPS Alert: Package 928301 could not be delivered due to wrong address. Pay $1.99 redelivery fee now: http://tinyurl.com/usps-redelivery-fee",
    "Wells Fargo Security: We detected an unauthorized login from Russia. Verify your SSN to unlock your card: http://wellsfargo-secure-login.ru",
    "IRS FINAL NOTICE: You owe $4,200 in delinquent taxes. Arrest warrant issued. Call 1-800-555-0199 immediately to avoid arrest.",
    "Bank of America: Your online banking has been temporarily disabled. Visit http://bofa-verify-identity.com to reactivate.",
    "Exclusive Crypto VIP signal: Earn 300% return guaranteed within 24 hours! Join WhatsApp group: https://t.me/cryptogains999",
    "Netflix: Your subscription payment failed. Your account will be closed today unless updated: http://netflix-billing-renew.info",
    "Toll Services: You have an unpaid toll invoice of $12.50. Late fees apply after 24h. Pay at: http://sunpass-toll-billing.top",
    "PayPal Security: Unauthorized transaction of $699.99 to Apple Store. Not you? Dispute immediately at: http://paypal-dispute-resolve.com",
    "You have (1) pending package awaiting clearance. Confirm your identity and pay customs fee: http://dhl-express-clearance.net/track",
    "URGENT: Your Apple ID has been locked for security reasons. Verify your account details: http://appleid-support-auth.com",
    "Alert from Citibank: Suspicious wire transfer of $2,450 initiated. Stop transfer here: http://citi-security-stop.com",
    "Winner notification! You have been selected for the 2026 Cash App Giveaway. Receive $750 instantly: http://cashapp-free750.online",
    "Your SIM card will be deactivated in 24 hours due to unverified KYC. Update details now: http://telecom-kyc-verify.club",
    "Amazon Security: Did you purchase iPhone 16 Pro for $1,199? If NOT, call fraud team right away at 1-888-555-0144.",
    "Dear customer, your debit card is blocked. Click http://chase-unblock-card.biz to submit photo ID and unlock.",
    "FedEx: Delivery exception! Package held at facility due to unpaid duty. Pay $2.40: http://fedex-express-customs.cc",
    "Target Shopper: You were chosen to receive a $500 shopping voucher! Complete short survey: http://target-voucher-survey.site",
    "Your social security number has been compromised in a fraud investigation. Press 1 to speak with a federal agent.",
    "Attn: Your account with AT&T will be cancelled. Pay overdue balance of $45.10 here: http://att-billpay-portal.info",
    "URGENT: Venmo unauthorized charge of $450 to Steam Games. Cancel this payment: http://venmo-security-dispute.link",
    "You qualified for $50,000 pre-approved loan with 0% APR. No credit check required! Apply now: http://fast-cash-loans-today.us",
    "Crypto alert: 1.45 BTC has been deposited to your wallet. Confirm receipt and withdraw: http://binance-claim-crypto.cc",
    "Your package #91823 is held at depot. Final delivery attempt tomorrow. Verify address: http://postal-package-update.info",
    "Warning: Your iPhone backup was compromised. Visit http://icloud-warning-check.me to change password immediately.",
    "Santander Alert: Card blocked due to suspicious activity. Follow link to verify: http://santander-unblock-service.top",
    "Work from home opportunity! Earn $500/day rating products on your phone. Telegram: @jobrecruiter2026",
    "Geek Squad: Auto-renewal charge of $399.99 processed. To request refund within 24h call: 1-800-555-0182",
    "Exclusive invitation: You are eligible to claim free government relief grant of $2,500. Register: http://gov-grant-claim.org",
    "TD Bank: Suspicious login from IP 194.26.29.1. Secure your account now: http://tdbank-customer-protect.net",
    "Capital One alert: Debit card flagged for fraud at Best Buy. Confirm identity: http://capitalone-fraud-prevention.xyz",
    "Your WhatsApp account will expire tomorrow. Renew your service for $0.99 here: http://whatsapp-subscription-renew.com",
    "URGENT legal notice: Process server dispatched to your location. Call 855-555-0129 to settle dispute before court.",
    "Costco rewards: You have $150 in unredeemed cash back rewards expiring tonight! Redeem at: http://costco-cashback-points.site",
    "Alert: Coinbase security key reset requested. If you did not initiate this, freeze account: http://coinbase-freeze-auth.com",
    "US Postal Notice: Missing apartment number on parcel. Re-enter shipping address: http://usps-address-correct.com",
    "Final reminder: Your car warranty is about to lapse. Extend coverage before deadline: http://auto-warranty-renew.online",
    "Your mobile number won 2nd prize in the UK National Lottery! Send email to claim: claim@national-lottery-promo.co",
    "Citizens Bank: Transaction of $840 declined. Verify your phone number to re-enable card: http://citizens-verify.cc",
]


def build_augmented_dataset() -> tuple[list[str], list[int], list[str]]:
    """Generates an augmented, balanced dataset of telecom SMS samples with template-family grouping."""
    texts: list[str] = []
    labels: list[int] = []
    groups: list[str] = []

    # Add base legitimate messages
    for idx, msg in enumerate(LEGITIMATE_MESSAGES):
        texts.append(msg)
        labels.append(0)
        groups.append(f"legit_base_{idx}")

    # Add base fraudulent messages
    for idx, msg in enumerate(FRAUDULENT_MESSAGES):
        texts.append(msg)
        labels.append(1)
        groups.append(f"fraud_base_{idx}")

    # Augment with variations (sender numbers, token variants, brand names)
    brands = [
        "Chase",
        "Wells Fargo",
        "Bank of America",
        "Citibank",
        "Capital One",
        "PayPal",
        "Venmo",
    ]
    scam_domains = [
        "verify-now.info",
        "secure-portal.xyz",
        "alert-check.cc",
        "id-verify.online",
        "login-help.top",
    ]

    for brand in brands:
        brand_key = brand.lower().replace(" ", "")
        for domain in scam_domains:
            texts.append(
                f"URGENT: {brand} security alert! Unusual sign-in detected. Confirm identity: http://{brand_key}-{domain}"
            )
            labels.append(1)
            groups.append(f"fraud_brand_{brand_key}")

    # Augment legit 2FA & transactional notifications
    service_names = [
        "Signal",
        "GitHub",
        "Stripe",
        "Auth0",
        "Okta",
        "Slack",
        "AWS",
        "Google",
        "Shopify",
        "Discord",
    ]
    for service in service_names:
        srv_key = service.lower()
        for code in [192840, 582910, 394821, 910283, 401928]:
            texts.append(
                f"{service} security code: {code}. It expires in 5 minutes. Never share this with anyone."
            )
            labels.append(0)
            groups.append(f"legit_2fa_{srv_key}")

    # Augment legit banking notifications (teaching model that legitimate banking alerts exist)
    legit_banks = [
        "Chase", "Wells Fargo", "Bank of America", "Citibank", "Capital One",
        "PNC Bank", "TD Bank", "US Bank"
    ]
    for i, b in enumerate(legit_banks):
        b_key = b.lower().replace(" ", "")
        for j in range(5):
            texts.append(
                f"{b} Update: Your checking account ending in {1000 + i * 100 + j} monthly statement is ready to view."
            )
            labels.append(0)
            groups.append(f"legit_bank_{b_key}")
            texts.append(
                f"{b}: Autopay confirmation for your utility bill payment of ${45 + j * 10}.00 processed."
            )
            labels.append(0)
            groups.append(f"legit_bank_{b_key}")
            texts.append(
                f"{b} Alert: Direct deposit of ${800 + j * 150}.00 from employer payroll posted successfully."
            )
            labels.append(0)
            groups.append(f"legit_bank_{b_key}")

    # Augment legit retail receipts & store pickups
    retail_chains = ["Target", "Walmart", "Best Buy", "Costco", "Starbucks", "Home Depot"]
    for i, r in enumerate(retail_chains):
        r_key = r.lower().replace(" ", "")
        for j in range(4):
            texts.append(
                f"{r} eReceipt: Order #{20000 + i * 100 + j} was paid in store. Thank you for your business."
            )
            labels.append(0)
            groups.append(f"legit_retail_{r_key}")
            texts.append(
                f"{r} Curbside: Order #{30000 + i * 100 + j} is ready for pickup in designated space."
            )
            labels.append(0)
            groups.append(f"legit_retail_{r_key}")

    # Augment legit travel & airline notifications
    airlines = ["Delta Air Lines", "United Airlines", "American Airlines", "Southwest Airlines"]
    for i, a in enumerate(airlines):
        a_key = a.lower().replace(" ", "")
        for j in range(5):
            texts.append(
                f"{a}: Flight confirmation #{4000 + i * 10 + j}. Check-in opens 24 hours prior to departure."
            )
            labels.append(0)
            groups.append(f"legit_airline_{a_key}")
            texts.append(
                f"{a} Gate Info: Your scheduled departure is on time at Gate {chr(65 + i)}{10 + j}."
            )
            labels.append(0)
            groups.append(f"legit_airline_{a_key}")

    # Augment legit healthcare notifications
    for i in range(20):
        texts.append(
            f"MyChart Notification: Patient test results #{5000 + i} from Dr. Taylor are now available online."
        )
        labels.append(0)
        groups.append(f"legit_health_mychart_{i // 4}")
        texts.append(
            f"Pharmacy Refill: Prescription #{6000 + i} is filled and ready for pickup at local counter."
        )
        labels.append(0)
        groups.append(f"legit_health_pharmacy_{i // 4}")

    # Augment legit conversational messages
    conversations = [
        ("Are we still on for lunch tomorrow afternoon?", "legit_convo_lunch"),
        ("Don't forget to lock the garage door on your way out.", "legit_convo_garage"),
        ("The kids had so much fun at the science museum today!", "legit_convo_museum"),
        ("Can you send over the slides from yesterday's presentation?", "legit_convo_slides"),
        ("Hope you have a safe and pleasant flight back home!", "legit_convo_flight"),
        ("See you at soccer practice on Tuesday evening.", "legit_convo_soccer"),
        ("Traffic is a bit heavy on highway 101, will be there shortly.", "legit_convo_traffic"),
        ("Dinner was delicious, thanks for having us over!", "legit_convo_dinner"),
        ("Let me know if you need any help with the garden this weekend.", "legit_convo_garden"),
        ("Just finished running at the park, heading home now.", "legit_convo_park"),
        ("Wishing you a very Happy Birthday and a fantastic year ahead!", "legit_convo_birthday"),
        ("Happy Birthday! Have an amazing day celebrating with friends!", "legit_convo_birthday"),
        ("Let me know if you want to carpool to soccer practice this weekend.", "legit_convo_carpool"),
        ("We can carpool to soccer practice on Saturday morning if you'd like.", "legit_convo_carpool"),
        ("Could you bring my umbrella from the front hallway to the office?", "legit_convo_umbrella"),
        ("Don't forget your umbrella today, looks like light rain this afternoon.", "legit_convo_umbrella"),
    ]
    for c_text, c_grp in conversations:
        texts.append(c_text)
        labels.append(0)
        groups.append(c_grp)

    # Augment fraud with financial and delivery scams
    banks_fraud = ["Barclays", "HSBC", "Santander", "Lloyds", "NatWest", "Standard Chartered"]
    scam_domains_extra = [
        "auth-alert.xyz", "secure-desk.top", "verify-card.cc", "login-gate.club", "resolve-fraud.biz"
    ]
    for b in banks_fraud:
        b_key = b.lower().replace(" ", "")
        for d in scam_domains_extra:
            texts.append(
                f"URGENT: {b} security alert! Suspicious activity detected. Unlock account: http://{b_key}-{d}"
            )
            labels.append(1)
            groups.append(f"fraud_bank_uk_{b_key}")

    for i in range(25):
        texts.append(
            f"Postal Alert: Package #{10000 + i * 7} requires customs fee of $2.50 to release shipment: http://parcel-clearance-{i}.info"
        )
        labels.append(1)
        groups.append(f"fraud_postal_customs_{i // 5}")

    return texts, labels, groups


def train_and_export_model(
    output_dir: str = "app/telecom/models",
    model_name: str = "sms_fraud_model.onnx",
    metadata_name: str = "sms_fraud_metadata.json",
) -> dict[str, Any]:
    """Trains the NLP model, evaluates performance metrics, and exports to ONNX."""
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    onnx_file = output_path / model_name
    metadata_file = output_path / metadata_name

    logger.info("Generating augmented telecom dataset...")
    texts, labels, groups = build_augmented_dataset()
    logger.info(
        "Total dataset size: %d samples (Legit: %d, Fraud: %d) across %d template groups",
        len(texts),
        labels.count(0),
        labels.count(1),
        len(set(groups)),
    )

    # Strictly verify zero train/test leakage against held-out adversarial evaluation set
    def _hash_text(t: str) -> str:
        return hashlib.sha256(re.sub(r"\s+", " ", t.strip().lower()).encode("utf-8")).hexdigest()

    held_out_texts, _ = get_held_out_evaluation_set()
    train_hashes = {_hash_text(t) for t in texts}
    held_out_hashes = {_hash_text(t) for t in held_out_texts}
    leakage = train_hashes.intersection(held_out_hashes)
    if leakage:
        raise ValueError(
            f"CRITICAL: Train/Test leakage detected in {len(leakage)} samples: {leakage}"
        )
    logger.info(
        "Leakage check passed: Zero normalized SHA-256 overlap between training corpus (%d) and held-out test suite (%d). "
        "Template families are isolated across folds. Semantic overlap is naturally present in real-world NLP domains.",
        len(train_hashes),
        len(held_out_hashes),
    )

    # Group-based train / validation split (80 / 20) with StratifiedGroupKFold
    sgkf = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=42)
    train_idx, val_idx = next(sgkf.split(texts, labels, groups=groups))
    x_train = [texts[i] for i in train_idx]
    y_train = [labels[i] for i in train_idx]
    x_test = [texts[i] for i in val_idx]
    y_test = [labels[i] for i in val_idx]

    groups_train = {groups[i] for i in train_idx}
    groups_val = {groups[i] for i in val_idx}
    if not groups_train.isdisjoint(groups_val):
        overlap = groups_train.intersection(groups_val)
        raise ValueError(f"CRITICAL: Template-family leakage between train and val: {overlap}")
    logger.info(
        "Group split verified: %d train groups (%d samples, %d legit / %d fraud) | %d val groups (%d samples, %d legit / %d fraud) | Group overlap: 0",
        len(groups_train),
        len(x_train),
        y_train.count(0),
        y_train.count(1),
        len(groups_val),
        len(x_test),
        y_test.count(0),
        y_test.count(1),
    )

    # Base Logistic Regression classifier
    base_clf = LogisticRegression(
        C=1.5,
        max_iter=1000,
        class_weight="balanced",
        random_state=42,
    )

    # 1. Uncalibrated pipeline (baseline for Brier score measurement)
    tfidf = TfidfVectorizer(
        ngram_range=(1, 2),
        sublinear_tf=True,
        max_features=2500,
        min_df=1,
    )
    uncalibrated_pipeline = Pipeline([("tfidf", tfidf), ("clf", base_clf)])
    uncalibrated_pipeline.fit(x_train, y_train)
    y_prob_uncal = uncalibrated_pipeline.predict_proba(x_test)[:, 1]
    brier_before = float(brier_score_loss(y_test, y_prob_uncal))

    # 2. Fully calibrated pipeline using 5-fold cross-validated Platt scaling (sigmoid)
    logger.info("Training CalibratedClassifierCV(LogisticRegression, method='sigmoid', cv=5)...")
    calibrated_clf = CalibratedClassifierCV(
        estimator=LogisticRegression(
            C=1.5,
            max_iter=1000,
            class_weight="balanced",
            random_state=42,
        ),
        method="sigmoid",
        cv=5,
    )
    calibrated_pipeline = Pipeline(
        [
            (
                "tfidf",
                TfidfVectorizer(
                    ngram_range=(1, 2),
                    sublinear_tf=True,
                    max_features=2500,
                    min_df=1,
                ),
            ),
            ("clf", calibrated_clf),
        ]
    )
    calibrated_pipeline.fit(x_train, y_train)

    # Evaluate calibrated model on stratified validation split
    y_pred = calibrated_pipeline.predict(x_test)
    y_prob = calibrated_pipeline.predict_proba(x_test)[:, 1]

    precision = float(precision_score(y_test, y_pred))
    recall = float(recall_score(y_test, y_pred))
    f1 = float(f1_score(y_test, y_pred))
    roc_auc = float(roc_auc_score(y_test, y_prob))
    pr_auc = float(average_precision_score(y_test, y_prob))
    brier_after = float(brier_score_loss(y_test, y_prob))
    report = classification_report(y_test, y_pred, output_dict=True)

    logger.info("Stratified Validation Split Results:")
    logger.info("  Brier Score (Before Calibration): %.4f", brier_before)
    logger.info("  Brier Score (After Calibration):  %.4f", brier_after)
    logger.info("  Precision: %.4f", precision)
    logger.info("  Recall:    %.4f", recall)
    logger.info("  F1 Score:  %.4f", f1)
    logger.info("  ROC-AUC:   %.4f", roc_auc)
    logger.info("  PR-AUC:    %.4f", pr_auc)

    # Export calibrated pipeline to ONNX with string tensor input
    logger.info("Exporting calibrated pipeline to ONNX format (opset 14)...")
    initial_type = [("text", StringTensorType([None, 1]))]
    onnx_model = to_onnx(calibrated_pipeline, initial_types=initial_type, target_opset=14)

    # Serialize ONNX model to disk
    with open(onnx_file, "wb") as f:
        f.write(onnx_model.SerializeToString())
    model_bytes = onnx_file.read_bytes()
    model_sha256 = hashlib.sha256(model_bytes).hexdigest()
    training_dataset_sha256 = hashlib.sha256(
        "".join(f"{t}:{lbl}" for t, lbl in zip(texts, labels, strict=True)).encode("utf-8")
    ).hexdigest()
    logger.info("Saved ONNX model to: %s (%d bytes, SHA256: %s)", onnx_file, len(model_bytes), model_sha256)

    # Execute empirical evaluation on strictly held-out adversarial test set
    logger.info("Running empirical evaluation on held-out adversarial test suite...")
    held_out_metrics = evaluate_onnx_model(onnx_file)
    held_out_metrics["brier_score_before_calibration"] = round(brier_before, 4)
    held_out_metrics["brier_score_after_calibration"] = round(brier_after, 4)
    export_ml_metrics(held_out_metrics)

    # Save comprehensive metadata
    metadata = {
        "model_name": "SentinelPulse-SMS-Fraud-ONNX",
        "version": "1.0.0",
        "architecture": "TfidfVectorizer(ngram_range=(1,2), sublinear_tf=True) -> CalibratedClassifierCV(LogisticRegression(C=1.5, class_weight=balanced), method=sigmoid, cv=5)",
        "framework": "scikit-learn + skl2onnx + onnxruntime",
        "opset": 14,
        "model_sha256": model_sha256,
        "training_dataset_sha256": training_dataset_sha256,
        "evaluation_dataset_sha256": held_out_metrics["evaluation_dataset_sha256"],
        "evaluation_timestamp": held_out_metrics["evaluation_timestamp"],
        "software_versions": held_out_metrics["software_versions"],
        "calibration": {
            "method": "sigmoid",
            "cv_folds": 5,
            "brier_score_before": round(brier_before, 4),
            "brier_score_after": round(brier_after, 4),
            "brier_score_improvement": round(brier_before - brier_after, 4),
        },
        "input_signature": {"text": "StringTensor([None, 1])"},
        "output_signature": {
            "label": "Int64Tensor([None])",
            "probabilities": "Sequence[Map[Int64, Float]]",
        },
        "validation_metrics": {
            "test_sample_count": len(y_test),
            "precision": round(precision, 4),
            "recall": round(recall, 4),
            "f1_score": round(f1, 4),
            "roc_auc": round(roc_auc, 4),
            "pr_auc": round(pr_auc, 4),
            "brier_score": round(brier_after, 4),
            "detailed_report": report,
        },
        "held_out_adversarial_metrics": held_out_metrics,
        "operating_thresholds": {
            "allow_below": 0.40,
            "flag_threshold": 0.40,
            "block_threshold": 0.75,
        },
        "target_latency": {
            "p50_ms": 0.05,
            "p95_ms": 0.15,
            "p99_ms": 0.50,
        },
    }

    with open(metadata_file, "w", encoding="utf-8") as meta_out:
        json.dump(metadata, meta_out, indent=2)
    logger.info("Saved model metadata to: %s", metadata_file)

    return metadata


if __name__ == "__main__":
    train_and_export_model()
